﻿using Expansion.Engine.Classes.GameFramework;

namespace Expansion.Engine.Classes.Camera
{
    public class Camera : Component
    {

    }
}