﻿namespace Expansion.Engine.Classes.GameFramework
{
    public class PlayerStart : GameObject
    {
    }
}