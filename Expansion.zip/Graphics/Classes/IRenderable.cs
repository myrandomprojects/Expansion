﻿namespace Expansion.Graphics.Classes
{
    public interface IRenderable
    {
    }
}