﻿namespace Expansion.Graphics.Providers.IProvider.Resources
{
    internal class VertexBuffer
    {
        public int Size { get; }

        public VertexBuffer(int size)
        {
            Size = size;
        }
    }
}