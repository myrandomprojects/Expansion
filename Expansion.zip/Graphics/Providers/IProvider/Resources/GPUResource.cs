﻿namespace Expansion.Graphics.Providers.IProvider.Resources
{
    public class GPUResource
    {
    }
}