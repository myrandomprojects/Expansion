﻿namespace Expansion.Graphics.Providers.IProvider.Resources
{
    internal class ShaderVariable
    {
    }
}