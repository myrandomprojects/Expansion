﻿using Expansion.Engine.Math3D;

namespace Expansion.Engine.Classes.GameFramework
{
    public class Component
    {
        public Transform Transform { get; set; }

        public GameObject Owner { get; set; }
    }
}